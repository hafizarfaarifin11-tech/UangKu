# UangKu : EWallet Sederhana

Starter project Android berbasis WebView lokal, siap dibuild melalui GitHub Actions (Android CI).

## Fitur versi awal
- Login menggunakan nama saja.
- ID akun demo dibuat otomatis oleh Android saat akun dibuat.
- Dashboard saldo demo.
- QR demo yang memuat ID akun dan nominal simulasi.
- Top up simulasi dan riwayat aktivitas.
- Data prototipe tersimpan di `localStorage` perangkat.

## Penting — ini belum e-wallet sungguhan
Versi ini **tidak menerima, menyimpan, mengirim, atau mencairkan uang sungguhan**. QR yang ditampilkan adalah QR teks berisi data `UANGKU-DEMO`; **bukan QRIS** dan tidak dapat dipakai untuk membayar. Tombol simulasi hanya menambah angka saldo lokal untuk menguji tampilan aplikasi.

Akun dibuat di satu perangkat. Karena belum ada backend, ID belum dikelola atau dijamin unik secara global, saldo tidak tersinkron antarperangkat, dan login nama saja bukan keamanan akun.

Untuk layanan uang sungguhan, proyek perlu backend yang aman, pencatatan transaksi di server, verifikasi pembayaran, serta integrasi penyedia pembayaran/merchant yang sah. Jangan menaruh secret key payment gateway di APK. Implementasi uang sungguhan harus ditinjau dan dikelola oleh orang dewasa yang bertanggung jawab serta mengikuti ketentuan penyedia dan aturan yang berlaku.

## Build APK dengan GitHub Actions
1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini ke root repository (folder `.github/workflows` harus ikut ter-upload).
3. Buka tab **Actions**.
4. Pilih workflow **Android CI** dan jalankan **Run workflow**, atau push commit ke branch `main` / `master`.
5. Setelah status build berhasil, buka hasil workflow dan unduh artifact **UangKu-debug-apk**.
6. Di dalam artifact terdapat `app-debug.apk`.

Workflow menggunakan JDK 17, Android SDK 36, Android Gradle Plugin 8.13.2 dan Gradle 8.13.

## Struktur penting
- `app/src/main/java/id/uangku/ewallet/MainActivity.java` — WebView dan pembuat ID/QR demo.
- `app/src/main/assets/index.html` — antarmuka aplikasi.
- `app/build.gradle` — konfigurasi aplikasi dan library QR Code.
- `.github/workflows/android.yml` — workflow build APK.
